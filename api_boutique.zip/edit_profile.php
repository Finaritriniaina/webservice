<?php 
	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');
	header("Content-Type: application/json; charset=UTF-8");


$postdata = file_get_contents("php://input");
$request = json_decode($postdata);


	 $data = [
	 	'pat_id' => $request->pat_id,	
	    'pat_rue1' => $request->adresse,
	    'pat_ville' => $request->ville,
	    'pat_pays' => $request->pays,
	    'pat_mail' => $request->mail,
	    'pat_telephone1' => $request->tel,
	    'pat_password' => $request->pwd,

	];

/*$pat_id = $request->pat_id;
$pays = $request->pays;
$tel = $request->tel;
$adresse = $request->adresse;
$email = $request->mail;
$pwd = $request->pwd;
$ville = $request->ville;*/

	$query = "UPDATE patients SET pat_pays=:pat_pays, pat_rue1=:pat_rue1, pat_ville=:pat_ville, pat_pays=:pat_pays, pat_mail=:pat_mail, pat_telephone1=:pat_telephone1, pat_password=:pat_password WHERE pat_id=:pat_id";

	$stmt= $PDO->prepare($query);
	$stmt->execute($data);

	echo json_encode($query);
 ?>
