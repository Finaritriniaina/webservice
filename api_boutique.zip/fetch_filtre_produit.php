<?php 

	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');
	header("Content-Type: application/json; charset=UTF-8");
	//$query = "SELECT * FROM filtre_produit";
	$num_sr = $_GET["num_sr"];
	
	$query = "SELECT * FROM produit INNER JOIN filtre_produit ON produit.prd_id=filtre_produit.prd_id WHERE srb_id=".$num_sr;

	$query2 = "SELECT stocks.prd_id, stocks.stk_quantite, stocks.stk_id from stocks, produit where produit.prd_id=stocks.prd_id AND produit.srb_id=".$num_sr;

	$data = $PDO->query($query);

	$cool = $data->fetchAll();

	$data2 = $PDO->query($query2);

	$stk_data = $data2->fetchAll();

	foreach ($cool as &$value) {
		$arr = "";
		$arr2 = "";
		foreach ($stk_data as $value2) {
			if($value["prd_id"] == $value2["prd_id"]){
				$arr = $value2["stk_quantite"];
				$arr2 = $value2["stk_id"];
			}
		}
		$value["prd_qte"] = $arr; $value["stk_id"] = $arr2;
	}

	echo json_encode($cool);
	/*$arr = array();

	while($row = $data->fetch()){
		$arr[] = $row;
	}
*/
 ?>

 