<?php

   // Define database connection parameters
   require_once 'db_connect.php';
   header('Access-Control-Allow-Origin:*');
   header('Access-Control-Allow-Methods:*');
   header('Access-Control-Allow-Headers:*');
   header("Content-Type: application/json; charset=UTF-8");
   $data    = array();


   // Attempt to query database table and retrieve data
   try {
      $stmt 	= $PDO->query('SELECT id, name, description FROM technologies ORDER BY name ASC');
      while($row  = $stmt->fetch(PDO::FETCH_OBJ))
      {
         // Assign each row of data to associative array
         $data[] = $row;
      }

      // Return data as JSON
      echo json_encode($data);
   }
   catch(PDOException $e)
   {
      echo json_encode($e->getMessage());
   }


?>