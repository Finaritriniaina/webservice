<?php 

	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');
	header("Content-Type: application/json; charset=UTF-8");


	$num_sr = $_GET["num_sr"];

	$query = "SELECT filtre.flt_id, filtre.flt_designation FROM filtre,filtre_srb WHERE filtre.flt_id=filtre_srb.flt_id AND filtre_srb.srb_id=".$num_sr;

	$query2 = "SELECT * FROM valeur_filtre";

	$query3 = "SELECT * FROM filtre_produit";

	$data = $PDO->query($query);

	$cool = $data->fetchAll();

	$data3 = $PDO->query($query3);

	$filtre_prod = $data3->fetchAll();

	$data2 = $PDO->query($query2);

	$valeur_filtre = $data2->fetchAll();

	$valeur = array();
	
	foreach ($cool as &$value) {
		$arr = [];
		foreach ($valeur_filtre as $value2) {
			if($value["flt_id"] == $value2["flt_id"]){
				array_push($arr, [ "vf_id" => $value2["val_id"], "value" => $value2["val_nom"], "isChecked" => "false"]);
				//array_push($arr["value"], {"isChecked" : "false"});
				//$arr["valeur"] = $value2["value"];
			}
		}
		$value["val_nom"] = $arr;
		$arr = [];
	//echo json_encode($value["flt_nom"]);
	}
		
	echo json_encode($cool);

	//echo json_encode($cool);
	//echo $json_info = json_encode($arr);
 ?>

 