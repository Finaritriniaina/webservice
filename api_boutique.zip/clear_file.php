<?php 

	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');
 $folder = 'uploads';
 
 $filename = $_GET["filename"];
//Get a list of all of the file names in the folder.
$files = glob($folder . '/*');

$filepath = "uploads/".$filename;
//Loop through the file list.
foreach($files as $file){
    //Make sure that this is a file and not a directory.
    if($file == $filepath){
        //Use the unlink function to delete the file.
        //echo "OK";
	unlink($file);
    }
  }
 ?>