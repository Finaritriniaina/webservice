<?php 

	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');

	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);

	$nom = $request->email;
	$prenom = $request->email;
	$email  = $request->email;
	$tel  = $request->tel;
	$adresse  = $request->adresse;
	$codePostal  = $request->codePostal;
	$ville  = $request->ville;
	$modeLivraison  = $request->modeLivraison;
	$departement  = $request->departement;
	$dateLivraison  = $request->dateLivraison;
	$horaireLivraison  = $request->horaireLivraison;
	$coms  = $request->coms;
	
	echo json_encode($postdata);


 ?>
