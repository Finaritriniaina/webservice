<?php 
	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');
	header("Content-Type: application/json; charset=UTF-8");


	$stk_qte = $_GET["stk_qte"];
	$stk_id = $_GET["stk_id"];


	 $data = [
	    'stk_quantite' => $stk_qte,
	    'stk_id' => $stk_id,
	];

	$query = "UPDATE stocks_demo SET stk_quantite=stk_quantite - :stk_quantite WHERE stk_id=:stk_id";

	$stmt= $PDO->prepare($query);
	$stmt->execute($data);

	echo json_encode("LASA AAAA");
 ?>
