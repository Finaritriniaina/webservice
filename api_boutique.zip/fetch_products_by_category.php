<?php 

	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');
	header("Content-Type: application/json; charset=UTF-8");



	$num_sr = $_GET["num_sr"];

	if (isset($_GET["page"])) {
		$page = $_GET["page"];
		$page *= 100;
	//$query = "SELECT * FROM produit where srb_id=".$num_sr." limit 0,10";
	$query = "SELECT * FROM produit where srb_id=".$num_sr." limit ".$page.",100";
	//$query = "SELECT * FROM produit where srb_id=".$num_sr;

	$query2 = "SELECT stocks.stk_id, stocks.prd_id, stocks.stk_quantite from stocks, produit where produit.prd_id=stocks.prd_id AND produit.srb_id=".$num_sr;

	$data = $PDO->query($query);

	$cool = $data->fetchAll();


	$data2 = $PDO->query($query2);

	$stk_data = $data2->fetchAll();
	

		foreach ($cool as &$value) {
		$arr = "";
		$arr2 = "";
		foreach ($stk_data as $value2) {
			if($value["prd_id"] == $value2["prd_id"]){
				$arr = $value2["stk_quantite"];
				$arr2 = $value2["stk_id"];
			}
		}
		$value["prd_qte"] = $arr; $value["stk_id"] = $arr2;
	}

	echo json_encode($cool);
	}

	else {
	$query = "SELECT * FROM produit where srb_id=".$num_sr." limit 0,100";

	$query2 = "SELECT stocks.prd_id, stocks.stk_quantite, stocks.stk_id from stocks, produit where produit.prd_id=stocks.prd_id AND produit.srb_id=".$num_sr;

	$data = $PDO->query($query);

	$cool = $data->fetchAll();


	$data2 = $PDO->query($query2);

	$stk_data = $data2->fetchAll();
	

		foreach ($cool as &$value) {
		$arr = "";
		$arr2 = "";
		foreach ($stk_data as $value2) {
			if($value["prd_id"] == $value2["prd_id"]){
				$arr = $value2["stk_quantite"];
				$arr2 = $value2["stk_id"];
			}
		}
		$value["prd_qte"] = $arr; $value["stk_id"] = $arr2;
	}
	echo json_encode($cool);
	}
	//echo $json_info = json_encode($arr);
 ?>

 