<?php 

	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');

	$query = "select * from produit";

	$data = $PDO->query($query);

	$row = $data->fetchAll(PDO::FETCH_OBJ);

	$arr = array();

	/*while($row = $data->fetch()){
		$arr[] = $row;
	}*/


	$json_info = json_encode($row);
	//echo $json_info = json_encode($arr);

	/*echo $row;*/
	echo utf8_encode($json_info);
 ?>