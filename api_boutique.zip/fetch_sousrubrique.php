<?php 

	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');
	header("Content-Type: application/json; charset=UTF-8");

	$rub_id = $_GET["rub_id"];

	$query = "SELECT * FROM sousrubrique WHERE rub_id=".$rub_id;

	$data = $PDO->query($query);

	$cool = $data->fetchAll();
	/*$arr = array();

	while($row = $data->fetch()){
		$arr[] = $row;
	}
*/
	echo json_encode($cool);
	//echo $json_info = json_encode($arr);
 ?>

 