<?php 
	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');
	header("Content-Type: application/json; charset=UTF-8");

	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);


	$nom = $request->Nom;
	$prenom = $request->Prenom;
	$email  = $request->Email;
	$tel  = $request->Tel;
	$adresse  = $request->Adresse;
	$password  = $request->password;
	$pat_num_insee  = $request->pat_num_insee;
	$pat_carte_vitale  = $request->pat_carte_vitale;
	$pat_mutuelle  = $request->pat_mutuelle;
	//$dateLivraison  = $request->dateLivraison;
	//$horaireLivraison  = $request->horaireLivraison;
	//$coms  = $request->coms;
	
	echo json_encode($postdata);

 ?>