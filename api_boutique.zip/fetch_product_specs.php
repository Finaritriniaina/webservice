<?php 

	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');
	header("Content-Type: application/json; charset=UTF-8");
	//$query = "SELECT filtre.flt_designation, valeur_filtre.val_nom from valeur_filtre, filtre_produit, filtre, filtre_srb WHERE valeur_filtre.flt_id = filtre.flt_id AND valeur_filtre.flt_id = filtre_produit.flt_id AND valeur_filtre.flt_id = filtre_srb.flt_id AND filtre_produit.flt_id = filtre_srb.flt_id AND filtre_produit.flt_id = filtre.flt_id AND filtre.flt_id = filtre_srb.flt_id AND filtre_produit.prd_id = 2 GROUP BY valeur_filtre.flt_id";
	$prd_id = $_GET["prd_id"];

	$query = "SELECT * FROM ((produit LEFT JOIN filtre_produit ON produit.prd_id=filtre_produit.prd_id) LEFT JOIN filtre ON filtre_produit.flt_id=filtre.flt_id) LEFT JOIN valeur_filtre ON filtre.flt_id=valeur_filtre.flt_id AND filtre_produit.val_id=valeur_filtre.val_id WHERE produit.prd_id=".$prd_id;
	$data = $PDO->query($query);

	$cool = $data->fetchAll();
	/*$arr = array();

	while($row = $data->fetch()){
		$arr[] = $row;
	}
*/
	echo json_encode($cool);
	//echo $json_info = json_encode($arr);
 ?>

