<?php 

	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');
	header("Content-Type: application/json; charset=UTF-8");
	$query = "SELECT * FROM rubrique";

	$data = $PDO->query($query);

	$cool = $data->fetchAll();
	
	echo json_encode($cool);
	//echo $json_info = json_encode($arr);
 ?>

 