<?php 

	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');

	$searchQuery = $_GET["query"];

	//$query = "SELECT * from produit where prd_reference LIKE '%".$searchQuery."%'";
	$query = "SELECT * from produit where prd_reference LIKE '%".$searchQuery."%'";


	$data = $PDO->query($query);

	$row = $data->fetchAll();
	
//echo json_encode($row);	//$arr = array();

	if($row == []){
		echo json_encode($row);
	}

	else {
		
	$query2 = "SELECT stocks.prd_id, stocks.stk_quantite, stocks.stk_id from stocks, produit where produit.prd_id=stocks.prd_id";
	$data2 = $PDO->query($query2);

	$stk_data = $data2->fetchAll();

	//$arr = array();

		foreach ($row as &$value) {
		$arr = "";
		$arr2 = "";
		foreach ($stk_data as $value2) {
			if($value["prd_id"] == $value2["prd_id"]){
				//array_push($arr, [ "prd_qte" => $value2["stk_quantite"] ]);
				$arr = $value2["stk_quantite"];
				$arr2 = $value2["stk_id"];
			}
		}
		
		$value["prd_qte"] = $arr; $value["stk_id"] = $arr2;
		}
		echo json_encode($row);
	}

 ?>