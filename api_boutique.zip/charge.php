﻿<?php

	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');

	$postdata = file_get_contents("php://input");
	$request = json_decode($postdata);
	
	require_once('../vendor/stripe/stripe-php/init.php');

	\Stripe\Stripe::setApiKey("sk_test_Y5vzHIzpcT30h0Cm7MrFNMy2");

	//$token = $_POST['stripeToken'];

	$charge = \Stripe\Charge::create([
	    'amount' => $request->amount,
	    //'amount' => 589,
	    'currency' => 'EUR',
	    'description' => 'Payement',
	  'source' => $request->token,
	  //'source' => $token,
	]);

	echo json_encode("Payement réussi avec succès !!!!!");
?>