<?php 
	//echo "Bonjour Test";

	$pdo_options[ PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;

	//$PDO = new PDO('mysql:host=medsoftsnddbtk94.mysql.db; dbname=medsoftsnddbtk94', 'medsoftsnddbtk94', 'EO4luFJkYj89c8DhFnuAi', $pdo_options);

	//$PDO = new PDO('mysql:host=localhost; dbname=db_boutique', 'root', '', $pdo_options);
	$PDO = new PDO('mysql:host=localhost; dbname=medsoft_boutique', 'root', '', $pdo_options);
	
	//$PDO = new PDO('odbc:DRIVER={HFSQL};Server Name=145.239.9.48;Server Port=4912; Database=ousoftsys;UID=admin;PWD=');

	$PDO->exec('SET NAMES UTF8');

	/*$PDOStat = $PDO->query('Select * from produit');

	$ToutesLesLignes = $PDOStat->fetchAll();

	echo json_encode($ToutesLesLignes);*/

 ?>