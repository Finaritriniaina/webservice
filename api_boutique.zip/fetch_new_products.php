<?php 
	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');

	$query = "select * from produit order by prd_date_crea limit 0,10";

	$query2 = "SELECT stocks.prd_id, stocks.stk_quantite, stocks.stk_id from stocks, produit where produit.prd_id=stocks.prd_id order by produit.prd_date_crea limit 0,10";
	
	$data = $PDO->query($query);

	$row = $data->fetchAll();

	$data2 = $PDO->query($query2);

	$stk_data = $data2->fetchAll();

	$arr = array();

		foreach ($row as &$value) {
		$arr = "";
		$arr2 = "";
		foreach ($stk_data as $value2) {
			if($value["prd_id"] == $value2["prd_id"]){
				$arr = $value2["stk_quantite"];
				$arr2 = $value2["stk_id"];
			}
		}
		$value["prd_qte"] = $arr; $value["stk_id"] = $arr2;
		$arr = []; $arr2 = [];
	}

	echo json_encode($row);
	//echo $json_info = json_encode($arr);

	/*echo $row;*/
	//echo utf8_encode($json_info);
 ?>