<?php 

	require_once 'db_connect.php';
	header('Access-Control-Allow-Origin:*');
	header('Access-Control-Allow-Methods:*');
	header('Access-Control-Allow-Headers:*');
	header("Content-Type: application/json; charset=UTF-8");

	$pat_code = $_GET["pat_code"];
	$pat_mail = $_GET["pat_mail"];


	$query = "SELECT *,COUNT(*) as 'patient' FROM patients WHERE pat_password = '".$pat_code."' AND pat_mail = '".$pat_mail."'";

	$data = $PDO->query($query);

	$cool = $data->fetch();
	/*$arr = array();

	while($row = $data->fetch()){
		$arr[] = $row;
	}
*/
/*	if($cool["patient"] == 1){
		echo json_encode($cool);
	} else {
		echo "wrong password";
	}*/
	echo json_encode($cool);
	//echo $json_info = json_encode($arr);
 ?>

 